﻿Set-ExecutionPolicy unrestricted
import-module "C:\Program Files (x86)\Microsoft Dynamics NAV\80\RoleTailored Client\NavModelTools.ps1"

Split-NAVApplicationObjectFile -Source "E:\BandB\NAV2015.txt" -Destination "E:\BandB\NAV2015\" -Force

Split-NAVApplicationObjectFile -Source "E:\BandB\Changed.txt" -Destination "E:\BandB\Changed\" -Force

Compare-NAVApplicationObject -OriginalPath "E:\BandB\NAV2015\" -ModifiedPath "E:\BandB\Changed\" -DeltaPath "E:\BandB\Delta\"

import-module "C:\Program Files\Microsoft Dynamics NAV\80\Service\NavAdminTool.ps1"

Invoke-NAVCodeunit -ServerInstance "BedAndBreakfast" -CodeunitId 84099 -CompanyName "CRONUS International Ltd." 
