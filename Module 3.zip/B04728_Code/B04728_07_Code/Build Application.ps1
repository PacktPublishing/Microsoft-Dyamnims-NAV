﻿Set-ExecutionPolicy unrestricted

import-module "C:\Program Files (x86)\Microsoft Dynamics NAV\80\RoleTailored Client\NavModelTools.ps1"
import-module "C:\Program Files\Microsoft Dynamics NAV\80\Service\NavAdminTool.ps1"

Push-Location #jump back to standard prompt with pop-location
import-module sqlps #ignore any warnings you may get

Set-NAVServerInstance "bedandbreakfast" –Stop

invoke-sqlcmd -ServerInstance ".\NAVDEMO" -U "powershell" -P "test" -Query "ALTER DATABASE [BedAndBreakfast (8-0)] SET  SINGLE_USER WITH ROLLBACK IMMEDIATE"
invoke-sqlcmd -ServerInstance ".\NAVDEMO" -U "powershell" -P "test" -Query "DROP DATABASE [BedAndBreakfast (8-0)]"
invoke-sqlcmd -ServerInstance ".\NAVDEMO" -U "powershell" -P "test" -Query "RESTORE DATABASE [BedAndBreakfast (8-0)] FROM  DISK = N'E:\Demo Database NAV (8-0).bak' WITH  FILE = 1,  MOVE N'Demo Database NAV (8-0)_Data' TO N'C:\SQLFiles\Demo Database NAV (8-0)_Data.mdf',  MOVE N'Demo Database NAV (8-0)_Log' TO N'C:\SQLFiles\Demo Database NAV (8-0)_Log.ldf',  NOUNLOAD,  STATS = 5"

Invoke-Sqlcmd -ServerInstance ".\NAVDEMO" -Database "BedAndBreakfast (8-0)" -Query "CREATE USER [NT AUTHORITY\NETWORK SERVICE] FOR LOGIN [NT AUTHORITY\NETWORK SERVICE]"

Invoke-Sqlcmd -ServerInstance ".\NAVDEMO" -Database "BedAndBreakfast (8-0)" -Query "exec sp_addrolemember 'db_owner', 'NT AUTHORITY\NETWORK SERVICE'"

Set-NAVServerInstance "bedandbreakfast" –Start 

Export-NAVApplicationObject -DatabaseName "BedAndBreakfast (8-0)" -Path "E:\BandB\Changed.txt" -DatabaseServer ".\NAVDEMO"  

Split-NAVApplicationObjectFile -Source "E:\BandB\Changed.txt" -Destination "E:\BandB\Changed\" -Force

$MergeResult = Update-NAVApplicationObject -TargetPath "E:\BandB\Changed\" `
                                           -DeltaPath  "E:\BandB\Delta\" `
                                           -ResultPath "E:\BandB\Result\" -Force

$MergeResult | Where-Object UpdateResult -eq Unchanged | foreach { Remove-Item -Path $_.PSPath } -Verbose‏  

Join-NAVApplicationObjectFile -Source "E:\BandB\Result\" -Destination "E:\BandB\Result.txt" 

Import-NAVApplicationObject -DatabaseName "BedAndBreakfast (8-0)" -Path "E:\BandB\Result.txt" -DatabaseServer ".\NAVDEMO"   

Compile-NAVApplicationObject -DatabaseName "BedAndBreakfast (8-0)" -DatabaseServer ".\NAVDEMO" -Filter 'Compiled=No' 

Invoke-NAVCodeunit -ServerInstance "bedandbreakfast" -CodeunitId 84099 -CompanyName "CRONUS International Ltd." 
